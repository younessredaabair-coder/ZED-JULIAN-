const crypto = require('crypto');

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '8854314859:AAGWOVwaWgn66cpPjLX0PYQ-wZ0gDjsfmcQ';
const ADMIN_ID = process.env.ADMIN_TELEGRAM_ID || '';
const SECRET = process.env.WEBHOOK_SETUP_SECRET || '';

function redisConfig() {
  return {
    url: process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL,
    token: process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN,
  };
}

async function redis(command, args = []) {
  const { url, token } = redisConfig();
  if (!url || !token) throw new Error('Redis is not configured');
  const encoded = args.map((v) => encodeURIComponent(String(v))).join('/');
  const r = await fetch(`${url}/${command}/${encoded}`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-store',
  });
  if (!r.ok) throw new Error(`Redis ${r.status}`);
  const data = await r.json();
  return data.result;
}

async function telegram(method, payload = {}) {
  const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return r.json();
}

function bodyOf(req) {
  if (!req.body) return {};
  if (typeof req.body === 'object') return req.body;
  try { return JSON.parse(req.body); } catch { return {}; }
}

function pathOf(req) {
  const raw = String(req.url || '');
  return raw.split('?')[0].replace(/\/+/g, '/');
}

function visitorId(req) {
  const cookie = String(req.headers.cookie || '');
  const match = cookie.match(/(?:^|;\s*)site_vid=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}

function setVisitorCookie(res, id) {
  res.setHeader('Set-Cookie', `site_vid=${encodeURIComponent(id)}; Path=/; Max-Age=31536000; SameSite=Lax; Secure`);
}

async function stats() {
  const n = async (key) => Number(await redis('get', [key]) || 0);
  const [views, unique, google, facebook, vk, x, apple, maintenance] = await Promise.all([
    n('stats:page_view'), redis('scard', ['stats:unique_visitors']), n('stats:click_google'),
    n('stats:click_facebook'), n('stats:click_vk'), n('stats:click_x'), n('stats:click_apple'),
    redis('get', ['site:maintenance']),
  ]);
  return { views, unique, google, facebook, vk, x, apple, maintenance: maintenance === '1' };
}

function panel() {
  return { inline_keyboard: [
    [{ text: '📊 Statistics', callback_data: 'stats' }, { text: '🔄 Status', callback_data: 'status' }],
    [{ text: '🛠 Maintenance ON', callback_data: 'on' }, { text: '✅ Maintenance OFF', callback_data: 'off' }],
  ] };
}

function statsText(s) {
  return [
    '📊 Website Statistics', '',
    `👥 Total page views: ${s.views}`,
    `🧑 Unique visitors: ${s.unique}`, '',
    `🔵 Google clicks: ${s.google}`,
    `🔷 Facebook clicks: ${s.facebook}`,
    `🟦 VK clicks: ${s.vk}`,
    `⚫ X clicks: ${s.x}`,
    `⚪ Apple clicks: ${s.apple}`, '',
    `🛠 Maintenance: ${s.maintenance ? 'ON' : 'OFF'}`,
  ].join('\n');
}

async function handleTrack(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { event } = bodyOf(req);
  const allowed = new Set(['page_view', 'click_google', 'click_facebook', 'click_vk', 'click_x', 'click_apple']);
  if (!allowed.has(event)) return res.status(400).json({ error: 'Invalid event' });
  let id = visitorId(req);
  if (!id) { id = crypto.randomUUID(); setVisitorCookie(res, id); }
  await redis('incr', [`stats:${event}`]);
  if (event === 'page_view') await redis('sadd', ['stats:unique_visitors', id]);
  return res.status(200).json({ ok: true });
}

async function handleStatus(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const maintenance = (await redis('get', ['site:maintenance'])) === '1';
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    return res.status(200).json({ maintenance });
  } catch {
    return res.status(200).json({ maintenance: false });
  }
}

async function setMaintenance(on) { await redis('set', ['site:maintenance', on ? '1' : '0']); }
function isAdmin(id) { return ADMIN_ID && String(id) === String(ADMIN_ID); }

async function handleTelegram(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (SECRET && req.headers['x-telegram-bot-api-secret-token'] !== SECRET) return res.status(401).json({ error: 'Unauthorized' });
  const update = bodyOf(req);
  const callback = update.callback_query;
  const message = update.message;
  if (callback) {
    const chatId = callback.message?.chat?.id;
    if (!isAdmin(chatId)) {
      await telegram('answerCallbackQuery', { callback_query_id: callback.id, text: 'Access denied.', show_alert: true });
      return res.status(200).json({ ok: true });
    }
    let text = 'Unknown action.';
    if (callback.data === 'stats') text = statsText(await stats());
    if (callback.data === 'status') text = `🛠 Maintenance: ${(await stats()).maintenance ? 'ON' : 'OFF'}`;
    if (callback.data === 'on') { await setMaintenance(true); text = '🛠 Maintenance mode is now ON.'; }
    if (callback.data === 'off') { await setMaintenance(false); text = '✅ Maintenance mode is now OFF.'; }
    await telegram('answerCallbackQuery', { callback_query_id: callback.id });
    await telegram('editMessageText', { chat_id: chatId, message_id: callback.message.message_id, text, reply_markup: panel() });
    return res.status(200).json({ ok: true });
  }
  if (!message?.chat?.id) return res.status(200).json({ ok: true });
  const chatId = message.chat.id;
  if (!isAdmin(chatId)) { await telegram('sendMessage', { chat_id: chatId, text: 'Access denied.' }); return res.status(200).json({ ok: true }); }
  const text = String(message.text || '').trim();
  const cmd = text.split(/\s+/)[0].toLowerCase();
  if (cmd === '/start' || cmd === '/panel') {
    await telegram('sendMessage', { chat_id: chatId, text: 'Admin Control Panel', reply_markup: panel() });
  } else if (cmd === '/stats') {
    await telegram('sendMessage', { chat_id: chatId, text: statsText(await stats()), reply_markup: panel() });
  } else if (cmd === '/maintenance') {
    const action = text.split(/\s+/)[1]?.toLowerCase();
    if (action === 'on') { await setMaintenance(true); await telegram('sendMessage', { chat_id: chatId, text: '🛠 Maintenance mode is now ON.', reply_markup: panel() }); }
    else if (action === 'off') { await setMaintenance(false); await telegram('sendMessage', { chat_id: chatId, text: '✅ Maintenance mode is now OFF.', reply_markup: panel() }); }
    else await telegram('sendMessage', { chat_id: chatId, text: `Maintenance: ${(await stats()).maintenance ? 'ON' : 'OFF'}\n\nUse /maintenance on or /maintenance off`, reply_markup: panel() });
  } else {
    await telegram('sendMessage', { chat_id: chatId, text: 'Use /panel to open the admin control panel.', reply_markup: panel() });
  }
  return res.status(200).json({ ok: true });
}

async function handleWebhookSetup(req, res) {
  if (SECRET && req.headers.authorization !== `Bearer ${SECRET}`) return res.status(401).json({ error: 'Unauthorized' });
  if (!BOT_TOKEN || !process.env.PUBLIC_BASE_URL) return res.status(500).json({ error: 'Missing bot token or public URL' });
  const url = `${process.env.PUBLIC_BASE_URL.replace(/\/$/, '')}/api/telegram`;
  const result = await telegram('setWebhook', { url, secret_token: SECRET || undefined, allowed_updates: ['message', 'callback_query'] });
  return res.status(result.ok ? 200 : 502).json(result);
}

module.exports = async (req, res) => {
  try {
    const path = pathOf(req);
    if (path.endsWith('/track')) return handleTrack(req, res);
    if (path.endsWith('/status')) return handleStatus(req, res);
    if (path.endsWith('/telegram')) return handleTelegram(req, res);
    if (path.endsWith('/set-webhook')) return handleWebhookSetup(req, res);
    return res.status(404).json({ error: 'Not found' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
};
